<?php
/**
 * VFM - veno file manager index
 *
 * PHP version >= 5.3
 *
 * @category  PHP
 * @package   VenoFileManager
 * @author    Nicola Franchini <info@veno.it>
 * @copyright 2013 Nicola Franchini
 * @license   Exclusively sold on CodeCanyon: http://bit.ly/veno-file-manager
 * @link      http://filemanager.veno.it/
 */
require_once 'vfm-admin/include/head.php';
?>
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!--addby Oblivion-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
/* reset */
html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video { margin: 0; padding: 0; border: 0; font-size: 100%; font: inherit; vertical-align: baseline; }
article, aside, details, figcaption, figure, footer, header, hgroup, menu, nav, section { display: block; }
body { line-height: 1; }
ol, ul { list-style: none; }
blockquote, q { quotes: none; }
blockquote:before, blockquote:after, q:before, q:after { content: ''; content: none; }
table { border-collapse: collapse; border-spacing: 0; }
body, input, textarea, select, button { font: 12px/1.6em '\5FAE\8F6F\96C5\9ED1', arial, '\5b8b\4f53'; color: #232323; outline: 0; }
a { color: #232323; }
.cb10 { height: 20px; }
/* m-tb */
.m-tb { width: 100%; }
.m-tb th { background-color: #CCCCCC; border: 1px solid #AAA; padding: 8px; }
.m-tb td { background-color: #EFEFEF; border: 1px solid #AAA; padding: 8px; }
.m-tb2 { width: 100%; }
.m-tb2 th { background-color: #dedede; border: 1px solid #666; padding: 8px; }
.m-tb2 td { background-color: #ffffff; border: 1px solid #666; padding: 8px; }
.m-tb3 { width: 60%; }
.m-tb3 th { background-color: transparent; border: 1px solid transparent; padding: 8px; }
.m-tb3 td { background-color: transparent; border: 1px solid transparent; padding: 8px; }
</style>
<!--addby Oblivion-->
    <title><?php print $setUp->getConfig("appname"); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="Content-Language" content="<?php print $encodeExplorer->lang; ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="vfm-admin/images/favicon.ico">
    <meta name="description" content="file manager">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <link rel="stylesheet" href="vfm-admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="vfm-admin/vfm-style.css">
    <?php 
    if ($setUp->getConfig("txt_direction") == "RTL") { ?>
        <link rel="stylesheet" href="vfm-admin/css/bootstrap-rtl.min.css">
    <?php 
    } ?>
    <link rel="stylesheet" href="vfm-admin/css/font-awesome.min.css">
    <link rel="stylesheet" href="vfm-admin/skins/<?php print $setUp->getConfig('skin') ?>">
    <script type="text/javascript" src="vfm-admin/js/jquery-1.12.4.min.js"></script>
    <!--[if lt IE 9]>
    <script src="vfm-admin/js/html5.js" type="text/javascript"></script>
    <script src="vfm-admin/js/respond.min.js" type="text/javascript"></script>
    <![endif]-->
    <?php
    $bodyclass = 'vfm-body';
    if ($setUp->getConfig('inline_thumbs') == true) {
        $bodyclass .= ' inlinethumbs';
    } ?>
</head>
    <body id="uparea" class="<?php echo $bodyclass; ?>">
        <div class="overdrag"></div>
            <?php
            /**
            * ************************************************
            * ******************** HEADER ********************
            * ************************************************
            */ 
            $template->getPart('activate');
            $template->getPart('navbar');
            ?>
        <?php
                /**
                * ************************************************
                * ******************** FOOTER ********************
                * ************************************************
                */
                $template->getPart('footer');
                $template->getPart('load-js');
                $template->getPart('modals');
            ?>
            <center>
<table class="m-tb3">

<h1 class="code-line code-line" data-line="0" id="%E5%85%B3%E4%BA%8E%E6%88%91%E4%BB%AC" style="border-bottom: 1px solid rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top-color: rgba(0, 0, 0, 0.18); color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; line-height: 1.2; padding-bottom: 0.3em; position: relative;">
关于我们</h1>
<h2 class="code-line code-line" data-line="2" id="%E5%BA%8F%E8%A8%80" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
序言</h2>
<div class="code-line code-line" data-line="4" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
在建立这个平台之前，我们有很多想法，相信您也会有许多疑问。</div>
<div class="code-line code-line" data-line="6" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
这个页面的建立，就是为了回答您的问题。</div>
<div class="code-line code-line" data-line="8" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
当然，我们知道，这个页面并不能囊括所有问题。</div>
<div class="code-line code-line" data-line="10" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
如果您有其它疑问，欢迎访问『联系我们』来获得我们的联系方式，并联系我们。</div>
<div class="code-line code-line" data-line="12" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
我们会<strong>尽快</strong>答复您的问题。但请注意，<em>在一些情况下，我们无法及时回复。</em></div>
<div class="code-line code-line" data-line="14" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
我们感谢您的来访，同时，我们期待您的提问！</div>
<div class="code-line code-line" data-line="16" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
ISP 项目组</div>
<h2 class="code-line code-line" data-line="18" id="%E5%85%B3%E4%BA%8E-isp" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
关于 ISP</h2>
<div class="code-line code-line" data-line="20" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
ISP 是影像共享平台『Image Sharing Platform』的英文缩写。</div>
<h3 class="code-line code-line" data-line="22" id="%E7%9B%AE%E7%9A%84" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
目的</h3>
<div class="code-line code-line" data-line="24" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
建立平台以共享已经公开却难以找到获取途径的照片，并且给希望公开照片的人一个平台。</div>
<h3 class="code-line code-line" data-line="26" id="%E5%AE%9A%E4%BD%8D" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
定位</h3>
<div class="code-line code-line" data-line="28" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
本平台将会是一个基于互联网的影像共享平台，将实现用户不同权限、实时可访问、下载、持权上传影像（在保证安全的情况下，可能拓展到所有文件）。</div>
<h3 class="code-line code-line" data-line="30" id="%E9%A2%84%E6%9C%9F" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
预期</h3>
<div class="code-line code-line" data-line="32" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
目前计划在自 2019 年起的 7 年内保持正常运营。</div>
<h2 class="code-line code-line" data-line="34" id="%E5%BC%80%E5%8F%91%E7%BB%84" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
开发组</h2>
<h3 class="code-line code-line" data-line="36" id="%E7%AE%80%E4%BB%8B" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
简介</h3>
<div class="code-line code-line" data-line="38" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
我们是来自杭州学军中学西溪校区 2019 级 12 班的<s>电竞</s>信竞选手。</div>
<h3 class="code-line code-line" data-line="40" id="%E5%88%9B%E5%A7%8B%E4%BA%BA" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
创始人</h3>
<div class="code-line code-line" data-line="42" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Algha_Porthos, Oblivion, McFun</div>
<h3 class="code-line code-line " data-line="44" id="%E6%88%90%E5%91%98" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
成员</h3>
<table style="border-collapse: collapse; color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px;"><thead>
<tr><th style="border-bottom: 1px solid rgba(0, 0, 0, 0.69); border-left-color: rgba(0, 0, 0, 0.69); border-right-color: rgba(0, 0, 0, 0.69); border-top-color: rgba(0, 0, 0, 0.69); padding: 5px 10px; text-align: left;">Name</th><th style="border-bottom: 1px solid rgba(0, 0, 0, 0.69); border-left-color: rgba(0, 0, 0, 0.69); border-right-color: rgba(0, 0, 0, 0.69); border-top-color: rgba(0, 0, 0, 0.69); padding: 5px 10px; text-align: left;">E-mail</th></tr>
</thead><tbody>
<tr><td style="padding: 5px 10px;">Algha_Porthos</td><td style="padding: 5px 10px;"><a data-href="mailto:2408201153@qq.com" href="mailto:2408201153@qq.com" style="text-decoration-line: none;" title="mailto:2408201153@qq.com">2408201153@qq.com</a></td></tr>
<tr><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">Oblivion</td><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;"><a data-href="mailto:oierlin@qq.com" href="mailto:oierlin@qq.com" style="text-decoration-line: none;" title="mailto:oierlin@qq.com">oierlin@qq.com</a></td></tr>
<tr><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">McFun</td><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;"><a data-href="mailto:mcfuns@vip.qq.com" href="mailto:mcfuns@vip.qq.com" style="text-decoration-line: none;" title="mailto:mcfuns@vip.qq.com">mcfuns@vip.qq.com</a></td></tr>
<tr><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">jljljl</td><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;"></td></tr>
</tbody></table>
<h3 class="code-line code-line" data-line="53" id="%E6%9C%8D%E5%8A%A1%E5%99%A8" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
服务器</h3>
<div class="code-line code-line" data-line="55" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
服务器目前使用阿里云学生机，配置如下：</div>
<div class="code-line code-line" data-line="57" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
系统：Ubuntu 18.04</div>
<div class="code-line code-line" data-line="59" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
流量：1000GB</div>
<div class="code-line code-line" data-line="61" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
CPU：1核</div>
<div class="code-line code-line" data-line="63" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
内存：2GB</div>
<div class="code-line code-line" data-line="65" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
系统盘：40GB</div>
<div class="code-line code-line" data-line="67" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
带宽：5Mbps</div>
<div class="code-line code-line" data-line="69" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
（突发性能服务器）</div>
<h3 class="code-line code-line" data-line="71" id="%E6%BA%90%E7%A0%81" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
源码</h3>
<div class="code-line code-line" data-line="73" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
我们的网站源码基于开源的『极简网盘』源码，经过ISP开发组的修改，以适应并且提供 ISP 相关服务。</div>
<div class="code-line code-line" data-line="75" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
当前，我们以<strong>云盘 / 图床</strong>为基础进行权限管理。</div>
<h2 class="code-line code-line" data-line="77" id="%E5%BD%B1%E5%83%8F%E7%89%88%E6%9D%83" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
影像版权</h2>
<div class="code-line code-line" data-line="79" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
若无特殊说明，本项目的<strong>所有公开影像</strong>的版权属于 ISABPR。</div>
<div class="code-line code-line" data-line="81" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
<strong>在经过版权方的授权后</strong>，我们为您转载压缩后的影像资源，但是版权方仍然保留所有权利，包括但不限于<strong>影像商用的权利</strong>、<strong>对更高画质影像保密的权利</strong>。</div>
<h2 class="code-line code-line" data-line="83" id="%E5%85%B3%E4%BA%8E-isab" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
关于 ISAB</h2>
<div class="code-line code-line" data-line="85" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
ISAB 成立于 2017 年 12 月，有 ISABPR、ISABHT 等小组、部门。</div>
<h2 class="code-line code-line" data-line="87" id="%E6%9C%89%E5%81%BF%E6%9C%8D%E5%8A%A1" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
有偿服务</h2>
<h3 class="code-line code-line" data-line="89" id="%E5%89%8D%E8%A8%80" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
前言</h3>
<div class="code-line code-line" data-line="91" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
作为一个非盈利组织，我们目前的成本均由团队承担，并且在可预见的未来，我们不会商业化。</div>
<div class="code-line code-line" data-line="93" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
但是影像设备的购买、维护与服务器开销**非常巨大。**为了使该项目能够更好地服务大众并且健康发展，我们提供有偿服务。</div>
<div class="code-line code-line" data-line="95" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
如果您需要更高画质的影像，则可以向我们提出申请。如果申请符合我们的要求，我们可以<strong>有偿提供</strong>少量的影像。</div>
<h3 class="code-line code-line" data-line="97" id="%E8%A6%81%E6%B1%82" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
要求</h3>
<ol style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px;">
<li class="code-line code-line" data-line="99" style="position: relative;"><div class="code-line code-line" data-line="99" style="position: relative;">
版权方为 ISABPR，或者版权方完全同意 ISP 赞助商计划的所有条款。</div>
</li>
<li class="code-line code-line" data-line="101" style="position: relative;"><div class="code-line code-line" data-line="101" style="position: relative;">
我们需要核实您的身份。</div>
</li>
<li class="code-line code-line" data-line="103" style="position: relative;"><div class="code-line code-line" data-line="103" style="position: relative;">
您想要有偿获得的影像必须符合以下条件的<strong>至少一项</strong>：</div>
</li>
</ol>
<div class="code-line code-line" data-line="105" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
<em>定义：人物“可以辨认”应该有如下特征的<strong>至少一项</strong>：1）任意ISP 团队成员认识 的；2）面部特征清晰的。</em></div>
<div class="code-line code-line" data-line="107" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅰ. 在影像中，您是<strong>唯一</strong>可以辨认的人（例：您的特写）；</div>
<div class="code-line code-line" data-line="109" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅱ. 影像中<strong>没有出现</strong>可以辨认的人（例：风景照）；</div>
<div class="code-line code-line" data-line="111" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅲ. 您已经获得了影像中可以辨认的<strong>所有人</strong>的<strong>书面</strong>许可（例：合影）；</div>
<div class="code-line code-line" data-line="113" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
<em>注解 Ⅲ：我们有审核的权利，但<strong>无审核的义务</strong>。您应当<strong>自行保证</strong>该书面许可的合规性。若因您<strong>未取得许可</strong>或<strong>伪造许可</strong>而引起<strong>任何</strong>纠纷，ISP 不负责任。</em></div>
<div class="code-line code-line" data-line="115" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅳ. 您作为影像中可以辨认的<strong>所有人</strong>的<strong>公认代表</strong>，向我们提出申请（例：班主任 / 班长申请班级合照）；</div>
<div class="code-line code-line" data-line="117" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅴ. 在极其特殊的情况下，经由&nbsp;<strong>ISP 或 / 和 ISAB</strong>&nbsp;的特别许可。</div>
<div class="code-line code-line" data-line="119" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
<em>注解 Ⅴ：我们会慎用该条款，并承担与此相关的责任。请注意，这可能意味着该条款的适用条件相当苛刻。特别地，若该许可由 ISAB 授予，则 ISP 团队不负责任。</em></div>
<ol start="4" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px;">
<li class="code-line code-line" data-line="121" style="position: relative;">您可以在未通知 ISP 的情况下对影像进行非盈利性使用，但需遵守以下规则：</li>
</ol>
<div class="code-line code-line" data-line="123" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅰ. 您的使用应当符合您当地的法律和 ISP 团队所在地的法律；</div>
<div class="code-line code-line" data-line="125" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅱ. 为保护您的创作，您应当视情况添加水印。</div>
<ol start="5" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px;">
<li class="code-line code-line" data-line="127" style="position: relative;"><div class="code-line code-line" data-line="127" style="position: relative;">
如果您需要通过影像盈利，应当获得 ISP 的<strong>另行许可</strong>。我们有权<strong>按比例</strong>在您的获利中获得<strong>适当数额</strong>的赞助，具体比例将<strong>另行协商</strong>确定。</div>
</li>
<li class="code-line code-line" data-line="129" style="position: relative;"><div class="code-line code-line" data-line="129" style="position: relative;">
您理解并同意：</div>
</li>
</ol>
<div class="code-line code-line" data-line="131" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅰ. ISP 当前是非盈利性组织，影像付费服务仅为平衡开支；</div>
<div class="code-line code-line" data-line="133" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅱ. 您的付费被视为<strong>赞助</strong>，因此我们无需为您提供发票；</div>
<div class="code-line code-line" data-line="135" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅲ. 在使用我们的图片时产生的<strong>任何纠纷</strong>都与我们无关，请注意遵守<strong>法律法规</strong>和<strong>道德规范</strong>；</div>
<div class="code-line code-line" data-line="137" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Ⅳ. 该协议最终解释权归 ISP 所有。</div>
<div class="code-line code-line" data-line="139" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
在特殊情况下，应通过和版权方的协商来确定计费标准。在非特殊情况下，我们的计费标准如下：</div>
<table style="border-collapse: collapse; color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px;"><thead>
<tr><th style="border-bottom: 1px solid rgba(0, 0, 0, 0.69); border-left-color: rgba(0, 0, 0, 0.69); border-right-color: rgba(0, 0, 0, 0.69); border-top-color: rgba(0, 0, 0, 0.69); padding: 5px 10px; text-align: left;">影像类型</th><th style="border-bottom: 1px solid rgba(0, 0, 0, 0.69); border-left-color: rgba(0, 0, 0, 0.69); border-right-color: rgba(0, 0, 0, 0.69); border-top-color: rgba(0, 0, 0, 0.69); padding: 5px 10px; text-align: left;">计费标准</th></tr>
</thead><tbody>
<tr><td style="padding: 5px 10px;">JPG 格式原图</td><td style="padding: 5px 10px;">0.2‰ 设备价格 / 张</td></tr>
<tr><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">RAW 格式原图</td><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">0.8‰ 设备价格 / 张</td></tr>
<tr><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">视频</td><td style="border-bottom-color: rgba(0, 0, 0, 0.18); border-left-color: rgba(0, 0, 0, 0.18); border-right-color: rgba(0, 0, 0, 0.18); border-top: 1px solid rgba(0, 0, 0, 0.18); padding: 5px 10px;">1‰ 设备价格 / 15 秒</td></tr>
</tbody></table>
<div class="code-line code-line" data-line="147" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
其中设备包括但不限于机身，镜头，麦克风，三脚架等。</div>
<div class="code-line code-line" data-line="149" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
我们的收益会有 25% 的比例用于维持 ISP 运营，其余金额归影像版权方进行分配。</div>
<h2 class="code-line code-line" data-line="151" id="%E6%8D%90%E6%AC%BE" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-weight: normal; position: relative;">
捐款</h2>
<div class="code-line code-line" data-line="153" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
我们接受捐款。</div>
<div class="code-line code-line" data-line="155" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
如果您愿意为我们捐款，可以访问『捐款链接』以获得相关信息。</div>
<div class="code-line code-line" data-line="157" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
捐款时请备注“<strong>ISP</strong>&nbsp;<strong>项目捐款</strong>”。</div>
<div class="code-line code-line" data-line="159" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
如果没有特别说明（如要求匿名），我们将在友链中添加您的信息。</div>
<div class="code-line code-line" data-line="161" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
<em>当然，我们也欢迎您通过『赞助商计划』来支持我们！</em></div>
<div class="code-line code-line" data-line="163" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
捐款链接：<a data-href="http://47.103.204.220/donate.php" href="http://47.103.204.220/donate.php" style="text-decoration-line: none;" title="http://47.103.204.220/donate.php">http://47.103.204.220/donate.php</a>（未来可能更改）</div>
<div class="code-line code-line" data-line="165" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
联系我们：<a data-href="http://47.103.204.220/contact.php" href="http://47.103.204.220/contact.php" style="text-decoration-line: none;" title="http://47.103.204.220/contact.php">http://47.103.204.220/contact.php</a>（未来可能更改）</div>
<div class="code-line code-line" data-line="167" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
Best Wishes</div>
<div class="code-line code-line code-active-line" data-line="169" style="color: #333333; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe WPC&quot;, &quot;Segoe UI&quot;, Ubuntu, &quot;Droid Sans&quot;, sans-serif; font-size: 14px; position: relative;">
ISP 项目组</div>

            
            

</table>
</center>
</html>
